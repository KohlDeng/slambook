# name_demo

介绍全局命名空间n,和局部命名空间nh("~").在launch文件中，定义全局命名空间下serial=5,局部命名空间下，serial=10.
讲解如何分别利用全局命名空间下n和局部命名空间下的nh，提取全局命名空间和局部命名空间下serial参数。

## 运行方法


```sh
$ roslaunch name_demo demo.launch #展示demo
``` 
