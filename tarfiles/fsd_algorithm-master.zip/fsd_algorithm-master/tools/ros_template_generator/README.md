# ROS_Template_Generator

Use template to generate a package for FSD-Project

## How to use

```bash
python3 generate.py
```
select language : C++ or Python  
input : package name, object name, class name
