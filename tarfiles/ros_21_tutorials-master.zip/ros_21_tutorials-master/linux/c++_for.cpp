/***********************************************************************
Copyright 2020 GuYueHome (www.guyuehome.com).
***********************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int a = 5;
    
    for(a; a<10; a++)
    {
        cout << "a = " << a << endl;
    }
    
    return 0;
}
