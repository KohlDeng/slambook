#pragma once
#ifndef CIRCLE_H
#define CIRCLE_H
class SocketCan
{
private:
	int sockfd;
	ros::Publisher can_topic_pub;
public:
	SocketCan();
	void can_send(can_frame f);
	void can_receive();
	void close_sockfd();
};

#endif

void convertSocketCANToMessage(const can_frame f, test::frame& m)            //const��������Ҫ����
{
	m.id = f.id;
	m.dlc = f.dlc;
	for (int i = 0; i < 8; i++)  // always copy all data, regardless of dlc.
	{
		m.data[i] = f.data[i];
	}
};

void convertMessageToSocketCAN(const test::frame& m, can_frame f)
{
  f.id = m.id;
  f.dlc = m.dlc;
  for (int i = 0; i < 8; i++)  // always copy all data, regardless of dlc.
  {
    f.data[i] = m.data[i];
  }
};

class TopicToSocketCAN:public SocketCan
{
private:
	ros::Subscriber can_topic_sub;
public:
	TopicToSocketCAN(ros::NodeHandle* nh):SocketCan();
	void msgCallback(const test::frame::ConstPtr& msg);
};