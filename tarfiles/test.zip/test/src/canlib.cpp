#include "canlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>

#include <ros/ros.h>
#include <test/frame.h>

using namespace std;

SocketCan::SocketCan()
{
	struct sockaddr_can addr;
	struct ifreq ifr;
	struct can_filter rfilter[5];
	sockfd = socket(PF_CAN, SOCK_RAW, CAN_RAW);//创建套接字
	printf("sockfd=%d", sockfd);
	if (sockfd < 0)
	{
		printf("creat sockfd error/n");
		getchar();
		exit(1);
	}
	strcpy(ifr.ifr_name, "can1");
	ioctl(sockfd, SIOCGIFINDEX, &ifr); //指定 can1 设备
	addr.can_family = AF_CAN;
	addr.can_ifindex = ifr.ifr_ifindex;
	bind(sockfd, (struct sockaddr *)&addr, sizeof(addr));//将套接字与 can1 绑定
														 //设置过滤规则
	rfilter[0].can_id = 0x11;
	rfilter[0].can_mask = CAN_SFF_MASK;
	rfilter[1].can_id = 0x320;
	rfilter[1].can_mask = CAN_SFF_MASK;
	rfilter[2].can_id = CAN_EFF_FLAG | 0x321;
	rfilter[2].can_mask = CAN_EFF_MASK;
	rfilter[3].can_id = 0x322;
	rfilter[3].can_mask = CAN_SFF_MASK;
	rfilter[4].can_id = CAN_EFF_FLAG | 0x325;//frame.can_id = CAN_EFF_FLAG | 0x123
	rfilter[4].can_mask = CAN_EFF_MASK;
	setsockopt(sockfd, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter, sizeof(rfilter));
}

void SocketCan::can_send(can_frame f)
{
	int nbytes;
	struct can_frame frame =  { 0 } ;
	frame.can_id = f.id;
	frame.can_dlc = f.dlc;
	for (int i = 0; i < 8; i++)  // always copy all data, regardless of dlc.
	{
		frame.data[i] = m.data[i];
	}

	nbytes = write(sockfd, &frame, sizeof(frame));
	printf("nbytes=%d ", nbytes);
	if (nbytes != sizeof(frame))
	{
		printf("Send Error\n");
	}
		
}

void SocketCan::can_receive(ros::NodeHandle* nh)
{
	int nbytes;
	struct can_frame frame;
	test::frame msg;
	printf("can_receive is starting working\n");
	can_topic_pub = nh->advertise<test::frame>("received_messages", 10);             //10代表缓冲队列的长度，有待实验确认
	ros::Rate loop_rate(10);
	while (1)
	{
		nbytes = read(sockfd, &frame, sizeof(frame)); //接收报文
													  //显示报文，还有其他操作涉及对报文的解析
		if (nbytes > 0)
		{
			printf("ID = 0x%X DLC = %d \n", frame.can_id,
				frame.can_dlc);

			convertSocketCANToMessage(frame, msg);
			can_topic_pub.publish(msg);
		}
		printf("%d/n", nbytes);
	}
	
}

void SocketCan::close_sockfd()
{
	close(sockfd);
}

void  TopicToSocketCAN::msgCallback(const test::frame::ConstPtr& msg)
{

	test::frame m = *msg.get();  
	struct can_frame f;  				  
	convertMessageToSocketCAN(m, f);
	SocketCan::can_send(f);
}

void TopicToSocketCAN(ros::NodeHandle* nh) :SocketCan()
{
	can_topic_sub = nh2->subscribe<test::frame>("sent_messages", 10,       //from_topic_to_socket
		boost::bind(&SocketCan::msgCallback, this, _1));
}

