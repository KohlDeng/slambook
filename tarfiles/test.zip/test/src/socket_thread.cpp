#include "canlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>
#include <thread>

#include <ros/ros.h>
#include <test/frame.h>

using namespace std;

int main(int argc,char **argv)
{
	SocketCan socketcan;
	ros::init(argc, argv, "socket_node");
	ros::NodeHandle nh1,nh2;

	thread t(&SocketCan::can_receive(&nh1), SocketCan(socketcan));         //from_socket_to_topic
	
	TopicToSocketCAN topic_to_socketcan(&nh2);
	ros::spin()

	t.join();
	socketcan.close_sockfd();
	;
	printf("main progress is over!\n");
	getchar();
	return 0;
}


